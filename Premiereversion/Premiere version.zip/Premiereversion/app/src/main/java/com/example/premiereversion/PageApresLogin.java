package com.example.premiereversion;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.widget.Button;
import android.widget.Toast;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import java.io.IOException;

import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;

public class PageApresLogin extends AppCompatActivity {

    private static final String SERVER_URL = "http://10.0.2.2:3000/utilisateurs";
    private String userId;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_page_apres_login);

        Button btnDeconnexion = findViewById(R.id.deconnexion);
        Button btnSupprimerCompte = findViewById(R.id.supprimerCompte);

        // 🔹 Logging received intent extras
        if (getIntent().getExtras() != null) {
            for (String key : getIntent().getExtras().keySet()) {
                Log.d("PageApresLogin", "Intent Extra: " + key + " = " + getIntent().getExtras().get(key));
            }
        }

        // 🔹 Change from "id_utilisateurs" to "id"
        userId = getIntent().getStringExtra("id_utilisateurs");

        if (userId == null || userId.isEmpty()) {
            Log.e("PageApresLogin", "Erreur: ID utilisateur non reçu!");
            Toast.makeText(this, "Erreur: ID utilisateur introuvable", Toast.LENGTH_LONG).show();
            finish();
            return;
        }

        Log.d("PageApresLogin", "Received User ID: " + userId);

        btnDeconnexion.setOnClickListener(view -> {
            Intent intent = new Intent(PageApresLogin.this, MainActivity.class);
            intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
            startActivity(intent);
            finish();
        });

        btnSupprimerCompte.setOnClickListener(view -> confirmerSuppression());
    }

    private void confirmerSuppression() {
        new AlertDialog.Builder(this)
                .setTitle("Supprimer le compte")
                .setMessage("Êtes-vous sûr de vouloir supprimer votre compte ? Cette action est irréversible.")
                .setPositiveButton("Oui", (dialog, which) -> supprimerCompte())
                .setNegativeButton("Non", null)
                .show();
    }

    private void supprimerCompte() {
        if (userId == null || userId.isEmpty()) {
            Toast.makeText(this, "Erreur: ID utilisateur introuvable", Toast.LENGTH_SHORT).show();
            return;
        }

        OkHttpClient client = new OkHttpClient();
        Request request = new Request.Builder()
                .url(SERVER_URL + "/" + userId)
                .delete()
                .build();

        new Thread(() -> {
            try {
                Response response = client.newCall(request).execute();
                if (response.isSuccessful()) {
                    runOnUiThread(() -> {
                        Toast.makeText(PageApresLogin.this, "Compte supprimé avec succès", Toast.LENGTH_SHORT).show();
                        Intent intent = new Intent(PageApresLogin.this, MainActivity.class);
                        intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
                        startActivity(intent);
                        finish();
                    });
                } else {
                    runOnUiThread(() -> Toast.makeText(PageApresLogin.this, "Erreur lors de la suppression", Toast.LENGTH_SHORT).show());
                }
            } catch (IOException e) {
                e.printStackTrace();
                runOnUiThread(() -> Toast.makeText(PageApresLogin.this, "Erreur serveur", Toast.LENGTH_SHORT).show());
            }
        }).start();
    }
}
