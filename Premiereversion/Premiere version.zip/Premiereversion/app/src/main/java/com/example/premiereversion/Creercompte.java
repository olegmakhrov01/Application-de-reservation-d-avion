package com.example.premiereversion;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import java.io.IOException;

import okhttp3.MediaType;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;

public class Creercompte extends AppCompatActivity {

    private static final String SERVER_URL = "http://10.0.2.2:3000/utilisateurs";

    private EditText editNom, editPrenom, editEmail, editPassword, editDateNaissance;
    private Button btnRegister;

    private Button btnAcceuil;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_creercompte);

        editNom = findViewById(R.id.creerNom);
        editPrenom = findViewById(R.id.creerPrenom);
        editEmail = findViewById(R.id.creerEmail);
        editPassword = findViewById(R.id.creerMotDePasse);
        editDateNaissance = findViewById(R.id.creerDateDeNaissance);
        btnRegister = findViewById(R.id.creerCompte);
        btnAcceuil = findViewById(R.id.pageAcceuil);

        btnAcceuil.setOnClickListener(view -> {
            Intent intent = new Intent(Creercompte.this, MainActivity.class);
            startActivity(intent);
        });

        btnRegister.setOnClickListener(view -> registerUser());
    }
    private void registerUser() {
        String nom = editNom.getText().toString();
        String prenom = editPrenom.getText().toString();
        String email = editEmail.getText().toString();
        String motDePasse = editPassword.getText().toString();
        String dateNaissance = editDateNaissance.getText().toString();

        User newUser = new User(nom, prenom, email, motDePasse, dateNaissance);
        String jsonData = newUser.getJson();

        OkHttpClient client = new OkHttpClient();

        RequestBody body = RequestBody.create(jsonData, MediaType.get("application/json; charset=utf-8"));
        Request request = new Request.Builder()
                .url(SERVER_URL)
                .post(body)
                .build();

        new Thread(() -> {
            try {
                Response response = client.newCall(request).execute(); // Synchronous request
                if (response.isSuccessful()) {
                    runOnUiThread(() -> Toast.makeText(Creercompte.this, "Compte créé!", Toast.LENGTH_SHORT).show());
                } else {
                    runOnUiThread(() -> Toast.makeText(Creercompte.this, "Erreur lors de l'inscription", Toast.LENGTH_SHORT).show());
                }
            } catch (IOException e) {
                e.printStackTrace();
                runOnUiThread(() -> Toast.makeText(Creercompte.this, "Erreur serveur", Toast.LENGTH_SHORT).show());
            }
        }).start();
    }
}


