package com.example.premiereversion;

public class User {
    private String nom;
    private String prenom;
    private String email;
    private String mot_de_passe;
    private String date_naissance;
    private String role = "user"; //Default role

    public User(String nom, String prenom, String email, String mot_de_passe, String date_naissance) {
        this.nom = nom;
        this.prenom = prenom;
        this.email = email;
        this.mot_de_passe = mot_de_passe;
        this.date_naissance = date_naissance;
    }

    public String getJson() {
        return "{ \"nom\": \"" + nom + "\", \"prenom\": \"" + prenom + "\", \"email\": \"" + email +
                "\", \"mot_de_passe\": \"" + mot_de_passe + "\", \"date_naissance\": \"" + date_naissance +
                "\", \"role\": \"user\" }";
    }
}

